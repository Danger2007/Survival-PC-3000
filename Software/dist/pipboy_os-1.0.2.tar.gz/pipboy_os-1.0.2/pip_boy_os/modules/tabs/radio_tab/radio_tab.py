import random
import time
import pygame
from datetime import datetime
from threading import Thread
import settings
import os
from util_functs import Utils
from .radio_station_loader import RadioStationLoader
from .playlist_manager import PlaylistManager
from .visualizer import Visualizer


class NVRadioList:
    def __init__(self, draw_space: pygame.Rect, font: pygame.font.Font):
        self.draw_space = draw_space
        self.font = font
        self.items = []
        self.selected_index = 0
        self.scroll_offset = 0
        self.visible_count = 8

    def set_items(self, items):
        self.items = items
        self.selected_index = max(0, min(self.selected_index, len(items) - 1))

    def change_selection(self, direction: bool):
        if not self.items:
            return
        if direction: # Up
            self.selected_index = max(0, self.selected_index - 1)
        else: # Down
            self.selected_index = min(len(self.items) - 1, self.selected_index + 1)

        if self.selected_index < self.scroll_offset:
            self.scroll_offset = self.selected_index
        elif self.selected_index >= self.scroll_offset + self.visible_count:
            self.scroll_offset = self.selected_index - self.visible_count + 1

    def render(self, screen, active_station_index, station_playing):
        if not self.items:
            return

        visible_items = self.items[self.scroll_offset : self.scroll_offset + self.visible_count]
        item_height = 24
        
        for i, item_text in enumerate(visible_items):
            actual_index = self.scroll_offset + i
            is_selected = (actual_index == self.selected_index)
            is_active = (actual_index == active_station_index and station_playing)

            item_rect = pygame.Rect(
                self.draw_space.left,
                self.draw_space.top + settings.LIST_TOP_MARGIN + (i * item_height),
                self.draw_space.width,
                item_height - 4
            )

            # Selection rectangle for the currently selected station
            if is_selected:
                pygame.draw.rect(screen, settings.PIP_BOY_LIGHT, item_rect, 1)

            # Selection square for active station
            sq_size = 6
            sq_x = item_rect.left + 8
            sq_y = item_rect.centery - (sq_size // 2)
            
            if is_active:
                sq_rect = pygame.Rect(sq_x, sq_y, sq_size, sq_size)
                pygame.draw.rect(screen, settings.PIP_BOY_LIGHT, sq_rect)

            text_x = item_rect.left + 22
            text_y = item_rect.centery - (self.font.get_height() // 2)

            text_color = settings.PIP_BOY_LIGHT
            text_surf = self.font.render(item_text, True, text_color)
            screen.blit(text_surf, (text_x, text_y))


class F4RadioList:
    def __init__(self, draw_space: pygame.Rect, font: pygame.font.Font):
        self.draw_space = draw_space
        self.font = font
        self.items = []
        self.selected_index = 0
        self.scroll_offset = 0
        self.visible_count = 8

    def set_items(self, items):
        self.items = items
        self.selected_index = max(0, min(self.selected_index, len(items) - 1))

    def change_selection(self, direction: bool):
        if not self.items:
            return
        if direction: # Up
            self.selected_index = max(0, self.selected_index - 1)
        else: # Down
            self.selected_index = min(len(self.items) - 1, self.selected_index + 1)

        if self.selected_index < self.scroll_offset:
            self.scroll_offset = self.selected_index
        elif self.selected_index >= self.scroll_offset + self.visible_count:
            self.scroll_offset = self.selected_index - self.visible_count + 1

    def render(self, screen, active_station_index, station_playing):
        if not self.items:
            return

        visible_items = self.items[self.scroll_offset : self.scroll_offset + self.visible_count]
        item_height = 24
        
        for i, item_text in enumerate(visible_items):
            actual_index = self.scroll_offset + i
            is_selected = (actual_index == self.selected_index)
            is_active = (actual_index == active_station_index and station_playing)

            item_rect = pygame.Rect(
                self.draw_space.left,
                self.draw_space.top + settings.LIST_TOP_MARGIN + (i * item_height),
                self.draw_space.width,
                item_height - 4
            )

            # Sfondo pieno di selezione stile Fallout 4
            if is_selected:
                pygame.draw.rect(screen, settings.PIP_BOY_LIGHT, item_rect)
                text_color = settings.BACKGROUND
                square_color = settings.BACKGROUND
            else:
                text_color = settings.PIP_BOY_LIGHT
                square_color = settings.PIP_BOY_LIGHT

            # Quadrato indicatore per la stazione attiva con spazio a sinistra
            if is_active:
                sq_size = 6
                sq_x = item_rect.left + 4
                sq_y = item_rect.centery - (sq_size // 2)
                sq_rect = pygame.Rect(sq_x, sq_y, sq_size, sq_size)
                pygame.draw.rect(screen, square_color, sq_rect)

            text_x = item_rect.left + 16
            text_y = item_rect.centery - (self.font.get_height() // 2)

            text_surf = self.font.render(item_text, True, text_color)
            screen.blit(text_surf, (text_x, text_y))


class RadioTab:
    def __init__(self, screen, tab_instance, draw_space: pygame.Rect):
        self.screen = screen
        self.tab_instance = tab_instance
        self.draw_space = draw_space

        self.date = Utils.get_date()
        self.time = Utils.get_time()

        self.tab_instance.init_footer(
            self, 
            (settings.SCREEN_WIDTH // 4, settings.SCREEN_WIDTH // 4), 
            self._init_footer_text()
        )
        self.main_font = pygame.font.Font(settings.ROBOTO_BOLD_PATH, 12)
        
        ui_style = str(getattr(settings, 'UI_STYLE', 'fallout_4')).lower()
        self.is_nv = ui_style in ('fallout_nv', 'fallout_new_vegas')
        
        # Distance from the left edge of the tab to the start of the station list
        list_left = self.draw_space.left + settings.TAB_SIDE_MARGIN + (5 if self.is_nv else 0)
        list_draw_space = pygame.Rect(
            list_left,
            self.draw_space.top,
            (self.draw_space.width // 2) - settings.TAB_SIDE_MARGIN,
            self.draw_space.height
        )
        
        if self.is_nv:
            self.station_list = NVRadioList(list_draw_space, self.main_font)
        else:
            self.station_list = F4RadioList(list_draw_space, self.main_font)

        self.station_playing = False
        self.active_station_index = None
        self.previous_station_index = None

        self.current_song = None
        self.radio_music_thread_running = True
        
        self.stations_loaded = False
        self.pending_station_names = []

        radio_type = getattr(settings, 'RADIO_TYPE', 'FILES').upper()
        
        if radio_type == 'FILES':
            if self.is_nv:
                sounds_dir = os.path.dirname(settings.RADIO_BASE_FOLDER)
                radio_folder = os.path.join(sounds_dir, 'Radio NV')
            else:
                radio_folder = settings.RADIO_BASE_FOLDER
        elif radio_type == 'FM':
            radio_folder = settings.RADIO_BASE_FOLDER
        else:
            radio_folder = settings.RADIO_BASE_FOLDER

        self.loader = RadioStationLoader(radio_folder, settings.DCR_INTERMISSIONS_BASE_FOLDER)
        self.playlist_manager = PlaylistManager()
        self.visualizer = Visualizer(self.draw_space, self.screen, self)

        # Thread for updating the footer time
        self.footer_time_thread = Thread(target=self.update_footer_time, daemon=True)
        self.footer_time_thread.start()

        Thread(target=self.load_radio_stations, daemon=True).start()
        Thread(target=self.update_radio_music, daemon=True).start()

    def _blit_footer_time(self):
        time_surface = self.tab_instance.footer_font.render(self.time, True, settings.PIP_BOY_LIGHT)
        self.tab_instance.update_footer(self, time_surface, (settings.SCREEN_WIDTH // 4 + 4, 2))

    def update_footer_time(self):
        while True:
            self.time = Utils.get_time()
            self.date = Utils.get_date()
            self.tab_instance.init_footer(
                self, 
                (settings.SCREEN_WIDTH // 4, settings.SCREEN_WIDTH // 4), 
                self._init_footer_text()
            )
            self._blit_footer_time()
            
            now = datetime.now()
            wait_time = 60 - now.second
            pygame.time.wait(wait_time * 1000)

    def _init_footer_text(self):
        footer_surface = pygame.Surface((settings.SCREEN_WIDTH, settings.BOTTOM_BAR_HEIGHT), pygame.SRCALPHA)
        date_surface = self.tab_instance.footer_font.render(self.date, True, settings.PIP_BOY_LIGHT)
        location_surface = self.tab_instance.footer_font.render(
            settings.FAKE_LOCATION if getattr(settings, 'GAME_ACCURATE_MODE', False) else getattr(settings, 'REAL_LOCATION', ''), 
            True, 
            settings.PIP_BOY_LIGHT
        )
        footer_surface.blit(date_surface, (2, 2))
        footer_surface.blit(location_surface, (settings.SCREEN_WIDTH - location_surface.get_width() - 2, 2))
        return footer_surface

    def load_radio_stations(self):
        radio_type = getattr(settings, 'RADIO_TYPE', 'FILES').upper()

        if radio_type == 'FILES':
            self.loader.load_radio_stations()
        elif radio_type == 'FM':
            pass

        self.pending_station_names = list(self.loader.radio_stations.keys())
        self.stations_loaded = True

    def play_station_switch_sound(self):
        if os.path.exists(settings.RADIO_STATIC_BURSTS_BASE_FOLDER):
            sounds = os.listdir(settings.RADIO_STATIC_BURSTS_BASE_FOLDER)
            if sounds:
                sound = random.choice(sounds)
                Utils.play_sfx(
                    os.path.join(settings.RADIO_STATIC_BURSTS_BASE_FOLDER, sound),
                    settings.VOLUME
                )

    def scroll(self, direction: bool):
        self.station_list.change_selection(direction)

    def handle_input(self, event):
        event_type = getattr(event, 'type', None)
        key = getattr(event, 'key', None)
        if event_type == pygame.KEYDOWN:
            if key in (pygame.K_UP, pygame.K_w):
                self.scroll(True)
                return True
            elif key in (pygame.K_DOWN, pygame.K_s):
                self.scroll(False)
                return True
            elif key in (pygame.K_RETURN, pygame.K_SPACE):
                self.select_station()
                return True
        return False

    def select_station(self):
        if self.station_list.selected_index == self.active_station_index:
            self.station_playing = not self.station_playing
        else:
            self.station_playing = True

        if not self.station_playing:
            Utils.play_sfx(settings.RADIO_TURN_OFF_SOUND)
        else:
            self.play_station_switch_sound()

        self.active_station_index = self.station_list.selected_index

    def update_radio_music(self):
        while self.radio_music_thread_running:
            if (self.active_station_index is not None and 
                self.station_playing and 
                self.loader.radio_stations):
                station_names = list(self.loader.radio_stations.keys())
                if self.active_station_index >= len(station_names):
                    pygame.time.wait(1000)
                    continue

                station_name = station_names[self.active_station_index]
                station = self.loader.radio_stations[station_name]

                if station_name not in self.playlist_manager.station_playlists:
                    self.playlist_manager.station_playlists[station_name] = {
                        "playlist": self.playlist_manager.generate_station_playlist_for_station(
                            station, station_name
                        ),
                        "index": 0,
                        "song_start_time": None,
                        "initialized": False
                    }
                playlist_data = self.playlist_manager.station_playlists[station_name]
                playlist = playlist_data["playlist"]
                index = playlist_data["index"]

                if index >= len(playlist):
                    playlist_data["playlist"] = self.playlist_manager.generate_station_playlist_for_station(
                        station, station_name
                    )
                    playlist_data["index"] = 0
                    playlist_data["song_start_time"] = None
                    playlist_data["initialized"] = False
                    index = 0
                    playlist = playlist_data["playlist"]

                if not playlist:
                    pygame.time.wait(1000)
                    continue

                current_song = playlist[index]
                if settings.DCR_INTERMISSIONS_BASE_FOLDER in current_song:
                    duration_ms = self.loader.intermissions.get(current_song, 0)
                else:
                    duration_ms = station["music_files"].get(current_song, 0)
                duration_sec = duration_ms / 1000.0

                if playlist_data["song_start_time"] is None:
                    if not playlist_data["initialized"]:
                        random_offset = random.uniform(0, max(0, duration_sec - 1))
                        playlist_data["song_start_time"] = time.time() - random_offset
                        playlist_data["initialized"] = True
                    else:
                        playlist_data["song_start_time"] = time.time()

                song_offset = time.time() - playlist_data["song_start_time"]

                if song_offset < duration_sec:
                    if self.current_song != current_song:
                        try:
                            pygame.mixer.music.load(current_song)
                            pygame.mixer.music.set_volume(settings.MUSIC_VOLUME)
                            pygame.mixer.music.play(start=song_offset)
                            self.current_song = current_song
                        except Exception as e:
                            print(f"Error playing {current_song}: {e}")
                            playlist_data["index"] += 1
                            playlist_data["song_start_time"] = None
                            self.current_song = None
                    else:
                        if not pygame.mixer.music.get_busy():
                            pygame.mixer.music.play(start=song_offset)
                else:
                    playlist_data["index"] += 1
                    playlist_data["song_start_time"] = None
                    self.current_song = None
                    pygame.mixer.music.stop()
            else:
                if pygame.mixer.music.get_busy():
                    pygame.mixer.music.stop()
                self.current_song = None

            wait_time = 300 if self.active_station_index is not None else 1000
            pygame.time.wait(wait_time)

    def handle_threads(self, tab_selected: bool):
        if tab_selected:
            self.visualizer.start()
        else:
            self.visualizer.stop()

    def render_visualizer_waves(self):
        self.visualizer.render()

    def render(self):
        if self.stations_loaded and self.pending_station_names:
            if hasattr(self.station_list, 'set_items'):
                self.station_list.set_items(self.pending_station_names)
            else:
                self.station_list.items = self.pending_station_names

            if hasattr(self.station_list, 'update_list'):
                self.station_list.update_list()
            elif hasattr(self.station_list, 'refresh'):
                self.station_list.refresh()

            self.pending_station_names = []

        self.tab_instance.render_footer(self)
        self.station_list.render(self.screen, self.active_station_index, self.station_playing)
        self.render_visualizer_waves()